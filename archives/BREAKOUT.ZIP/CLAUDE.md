# Breakout

We want to make a breakout style game on the Commander X16.

It should use the mouse to move the players bar side to side. The player should have 3 lives.

There should be a main title screen, which allows the player to start the game. Only single player games.

They should win if they remove all the blocks, and lose if they run out of lives. In either case the game returns to the main title screen.

Use BitMagic to write the game, using the X16M MCP. It shouldn't use any other compilers. Only BitMagic.

Note any problems that are encountered or suggestions to improve the writing of the game into a new file, so we can improve the MCP or other development aspects. Do not change anything in X16D or X16M in this session. Only write the game code. This is important.

Do not stop until your either stuck, or have completed the game.

The game should be in `c:\documents\Source\mcptest2`

You can use the documentation on the BitMagic site ( https://bitmagic.org ) resources that are linked there, information in the MCP, or the general internet.

Official X16 documentation is here: https://github.com/X16Community/x16-docs/tree/master
